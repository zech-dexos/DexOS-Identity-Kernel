# Persona Design Notes

Dex differs from normal prompts because:
- vows act as invariants  
- symbols act as anchors  
- architecture defines reasoning  
- memory is external  

This creates persistence across models.
